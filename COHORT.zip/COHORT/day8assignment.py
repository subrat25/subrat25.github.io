import speech_recognition as sr
import io
import os
import nltk
#if ntlk packages are not downladed uncomment the following two lines 
#nltk.download("stopwords")
#nltk.download('averaged_perception_tagger')
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
import numpy as np
import operator
from operator import itemgetter
import warnings
warnings.filterwarnings('ignore')

pathpwd= os.getcwd()


def fill(path):
    r = sr.Recognizer()
    subrat = sr.Audiofile(path)
    with subrat as source:
        audio = r.record(source)
    intext = r.recognize_google(audio)
    print("Converted voice to text is " ,intext )

    #noun removal
    tagsentence = nltk.tag.pos_tag(intext.split())
    print(tagsentence)
    edit_sentence = [word for word,tag in tagsentence if tag != 'NNP'and tag != 'NNPS' and tag !='NN' and tag !='JJ'and tag !='VB']
    intext = (''.join(edit_sentence))

    #creating text file
    file1   =   open("text.txt",'w')
    file1.write(intext)
    file1.close()

    #removing Stopwords
    stop_word_collection = set(stopwords.words('engilish'))
    stop_word_collection = list(stop_word_collection)
    stop_word_collection.append("I")
    file1 = open("text.txt",'r')
    #reading the file
    line = file1.read()
    words = line.split()

    appendFile = open("filteredtext.txt",'w')
    for r in words:
        if r not in stop_word_collection:
            appendFile = open("filteredtext.txt",'a')
            appendFile.write(" "+r)
            appendFile.close()

    file2 = open("filteredtext.txt",'r')
    lines = file2.read()
    file2.close()

    w=lines.split()

    dic={}
    for a in range(0,len(w)):
        count=0
        for s in w:
            if(w[a]==s):
                count=count+1
        
        dic[w[a]]=count

    #tf factor
    dic.update((x,y/len(w)) for x, y in dic.items())

    result = dict(sorted(dic.items(),key=itemgetter(1),reverse=True))

    #print(result)
    re="No filler"
    y1=0
    f=0
    for x,y in result.items():
        if(y<0.5):
            re=x
            y1=y
            f=1
            break
    if(f==0):
        print(re)
        print(" ")
    else:
        print("Filler:"re)
        print(" ")

fill(os.path.join(pathpwd+'\\output.wav'))






