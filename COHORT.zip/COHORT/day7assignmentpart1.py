import speech_recognition as sr 
import pyttsx3 
import string 
import wave

# Initialize the recognizer 
r = sr.Recognizer() 
textFile = open("inputtext7.txt",'w')


def main():
    print('wait for 3 sec then, speak')
    while True:
        try:
            datainput=conv()
            textFile = open("inputtext7.txt",'a')
            textFile.write(" "+datainput)
            textFile.close()
            
        except KeyboardInterrupt:
            break

#converting text to voice    
def SpeakText(command): 
	
	# Initialize the engine 
	engine = pyttsx3.init() 
	engine.say(command) 
	engine.runAndWait() 
	
	
# Loop infinitely for user to 

# convert voice to text 
def conv():
    with sr.Microphone() as source2: 
        
			
		# wait for a second to let the recognizer 
		# adjust the energy threshold based on 
		# the surrounding noise level 
        
        # r.adjust_for_ambient_noise(source2, duration=0.2) 
            
		#listens for the user's input 
            
        audio2 = r.listen(source2) 
            
        print("converting to text")
			# Using ggogle to recognize audio 
           
        MyText = r.recognize_google(audio2) 
        MyText = MyText.lower() 
        #SpeakText(MyText)
            
    return MyText


if __name__ == "__main__":
    main()