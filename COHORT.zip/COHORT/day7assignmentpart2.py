import pyttsx3 
import string 


textFile = open("inputtext7.txt",'r')
line = textFile.read()

def main():
    convert2wav(line)
    SpeakText("Contents of your saved wav file are " + line)
    
def SpeakText(command): 
	
	# Initialize the engine 
	engine = pyttsx3.init() 
	engine.say(command) 
	engine.runAndWait()

def convert2wav(command): 
	
	# Initialize the engine 
	engine = pyttsx3.init() 
	engine.save_to_file(command, 'speech.wav')
	engine.runAndWait()

if __name__ == "__main__":
    main()